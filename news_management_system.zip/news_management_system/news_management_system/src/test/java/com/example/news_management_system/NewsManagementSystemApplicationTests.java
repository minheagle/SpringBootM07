package com.example.news_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
